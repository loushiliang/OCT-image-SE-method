﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace SE
{
    class readADD
    {
        //图像叠加成像
        [DllImport("DLL-imageadd.dll", EntryPoint = "imageSE")]
        unsafe public static extern int imageSE(byte* nameimageup, out double judge);
 
    }
}
