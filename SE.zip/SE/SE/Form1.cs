﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SE
{
    public partial class Form1 : Form
    {

        public Image Zimage, Zimage2;
        public string name, name2;
        double cost = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            name = textBox1.Text.ToString();

            unsafe
            {
                IntPtr nameimageup = Marshal.StringToHGlobalAnsi(name);
                byte* nameimageup2 = (byte*)nameimageup;
                int read1 = readADD.imageSE(nameimageup2, out cost);
            }
            string ZHs = cost.ToString() + "秒";
            textBox2.Text = ZHs;                              

 
            string str1;
            str1 = name + ".tif";
            System.Drawing.Image image1 = Image.FromFile(@"..\..\..\..\test\" + str1);  
            Zimage = new Bitmap(image1);
            pictureBox1.Image = Zimage;

 
            string str2;
            str2 = name + "SE.bmp";
            System.Drawing.Image image2 = Image.FromFile(@"..\..\..\..\test\" + str2); 
            Zimage2 = new Bitmap(image2);
            pictureBox2.Image = Zimage2;
               
            








        }

    }
}
